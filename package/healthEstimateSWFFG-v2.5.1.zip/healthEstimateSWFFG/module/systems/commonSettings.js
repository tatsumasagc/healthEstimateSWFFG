export const addTemp = {
	'core.addTemp': {
		type   : Boolean,
		default: false
	}
}

export const breakOnZeroMaxHP = {
	'core.breakOnZeroMaxHP': {
		type   : Boolean,
		default: true
	}
}
